from office365.entity import Entity


class OnenoteEntityBaseModel(Entity):
    """This is the base type for OneNote entities."""

    pass
