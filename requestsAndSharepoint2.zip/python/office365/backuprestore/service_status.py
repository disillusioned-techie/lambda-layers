from office365.runtime.client_value import ClientValue


class ServiceStatus(ClientValue):
    """Represents the tenant-level service status of the backup service."""
