from office365.entity import Entity


class DataSource(Entity):
    """The dataSource entity is an abstract base class used to identify sources of content for eDiscovery."""
