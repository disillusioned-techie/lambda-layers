from office365.runtime.client_value import ClientValue


class AlertComment(ClientValue):
    """An analyst-generated comment that is associated with an alert or incident."""
