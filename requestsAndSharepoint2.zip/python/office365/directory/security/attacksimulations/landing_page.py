from office365.entity import Entity


class LandingPage(Entity):
    """Represents an attack simulation landing page."""
