from office365.entity import Entity


class UserStorage(Entity):
    """"""
