from office365.directory.protection.threatassessment.requests.request import (
    ThreatAssessmentRequest,
)


class UrlAssessmentRequest(ThreatAssessmentRequest):
    """
    Used to create and retrieve a URL threat assessment, derived from threatAssessmentRequest.
    """
