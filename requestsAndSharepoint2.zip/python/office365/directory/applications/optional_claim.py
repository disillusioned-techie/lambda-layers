from office365.runtime.client_value import ClientValue


class OptionalClaim(ClientValue):
    """Contains an optional claim associated with an application"""
