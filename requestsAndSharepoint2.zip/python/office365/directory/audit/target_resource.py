from office365.runtime.client_value import ClientValue


class TargetResource(ClientValue):
    """Represents target resource types associated with audit activity."""
