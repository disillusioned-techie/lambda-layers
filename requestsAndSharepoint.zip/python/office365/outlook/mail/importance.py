class Importance:
    """The importance of the message"""

    def __init__(self):
        pass

    low = "low"

    normal = "normal"

    high = "high"
