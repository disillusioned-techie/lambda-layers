from office365.entity import Entity


class Post(Entity):
    """Represents an individual Post item within a conversationThread entity."""
