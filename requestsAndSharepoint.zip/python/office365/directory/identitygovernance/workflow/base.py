from office365.entity import Entity


class WorkflowBase(Entity):
    """An abstract type that exposes the properties for configuring a custom lifecycle workflow."""
