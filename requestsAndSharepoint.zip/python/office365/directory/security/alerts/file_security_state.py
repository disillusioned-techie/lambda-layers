from office365.runtime.client_value import ClientValue


class FileSecurityState(ClientValue):
    """Contains information about the file (not process) related to the alert."""
