class AlertStatus:
    """"""

    unknown = "0"
