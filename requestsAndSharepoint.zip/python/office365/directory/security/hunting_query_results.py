from office365.runtime.client_value import ClientValue


class HuntingQueryResults(ClientValue):
    """The results of running a query for advanced hunting."""
