from office365.entity import Entity


class WorkbookChartFill(Entity):
    """Represents the fill formatting for a chart element."""
