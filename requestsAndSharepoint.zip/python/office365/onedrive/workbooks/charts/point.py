from office365.entity import Entity


class WorkbookChartPoint(Entity):
    """Represents a point of a series in a chart."""
