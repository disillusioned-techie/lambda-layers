from office365.entity import Entity


class WorkbookChartFont(Entity):
    """This object represents the font attributes (font name, font size, color, etc.) for a chart object."""
