from office365.onedrive.sitepages.webparts.web_part import WebPart


class TextWebPart(WebPart):
    """Represents a text web part instance on a SharePoint page."""
