from office365.entity import Entity


class ExternalItem(Entity):
    """An item added to a Microsoft Graph connection."""
